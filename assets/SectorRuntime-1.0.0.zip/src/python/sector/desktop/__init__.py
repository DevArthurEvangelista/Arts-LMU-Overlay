"""Sector desktop components."""
