"""Sector telemetry components."""
