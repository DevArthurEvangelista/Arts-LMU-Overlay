"""Sector source package."""
