"""Sector replay components."""
