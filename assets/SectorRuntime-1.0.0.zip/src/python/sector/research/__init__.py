"""Sector research components."""
