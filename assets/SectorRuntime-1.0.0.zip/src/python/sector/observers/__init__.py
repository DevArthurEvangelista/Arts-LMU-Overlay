"""Sector observers components."""
