"""Sector analysis components."""
